module magazin {
	requires java.desktop;
}